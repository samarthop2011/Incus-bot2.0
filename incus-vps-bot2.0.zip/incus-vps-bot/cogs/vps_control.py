import time

import discord
from discord.ext import commands, tasks

from utils.db import (
    delete_vps_record,
    get_all_vps,
    get_user,
    get_user_vps,
    get_vps,
    load_config,
    update_vps,
)
from utils.embeds import (
    error_embed,
    make_embed,
    success_embed,
    vps_credentials_embed,
    vps_dashboard_embed,
    warn_embed,
)
from utils.incus import (
    SSH_UNAVAILABLE,
    bootstrap_vps,
    create_ssh_link,
    exec_in,
    gen_password,
    get_live_stats,
    launch_vps,
    list_instances,
    set_root_password,
    snapshot_action,
    vps_action,
    wait_for_ipv4,
)
from utils.provision import deploy_semaphore


async def _fail(interaction: discord.Interaction, exc: Exception):
    embed = error_embed("ACTION FAILED", f"`{str(exc)[:500]}`")
    if interaction.response.is_done():
        await interaction.followup.send(embed=embed, ephemeral=True)
    else:
        await interaction.response.send_message(embed=embed, ephemeral=True)


async def _dm(bot, user_id: int | str, embed: discord.Embed):
    try:
        user = bot.get_user(int(user_id)) or await bot.fetch_user(int(user_id))
        await user.send(embed=embed)
    except (discord.HTTPException, discord.NotFound):
        pass


class OwnerView(discord.ui.View):
    """Only the VPS owner may press these controls (even if the panel is posted publicly)."""

    def __init__(self, owner_id: int, timeout: float | None = 300):
        super().__init__(timeout=timeout)
        self.owner_id = owner_id

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message(
                embed=error_embed("NOT YOUR VPS", "These controls belong to another user."), ephemeral=True)
            return False
        return True


class ConfirmDeleteView(OwnerView):
    def __init__(self, owner_id: int, vps_id: str):
        super().__init__(owner_id, 60)
        self.vps_id = vps_id

    @discord.ui.button(label="▸ Confirm Delete", style=discord.ButtonStyle.danger)
    async def confirm(self, interaction: discord.Interaction, _):
        await interaction.response.defer(ephemeral=True)
        fresh = await get_vps(self.vps_id)
        if not fresh:
            return await interaction.followup.send(embed=error_embed("NOT FOUND", "Instance already deleted."), ephemeral=True)
        try:
            await vps_action(self.vps_id, "delete")
        except Exception as exc:
            return await _fail(interaction, exc)
        await delete_vps_record(self.vps_id)
        await interaction.followup.send(
            embed=success_embed("VPS TERMINATED", f"Instance `{self.vps_id}` has been permanently deleted."), ephemeral=True)


class ReinstallOSView(OwnerView):
    def __init__(self, owner_id: int, vps_id: str):
        super().__init__(owner_id, 120)
        self.vps_id = vps_id
        opts = [discord.SelectOption(label=f"▸ {n}", value=n) for n in load_config()["images"]]
        sel = discord.ui.Select(placeholder="▸ Pick new OS (wipes all VPS data)...", options=opts)
        sel.callback = self.on_reinstall
        self.add_item(sel)

    async def on_reinstall(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True, thinking=True)
        bot = interaction.client
        if interaction.user.id in bot.deploying_users:
            return await interaction.followup.send(embed=warn_embed("IN PROGRESS", "A job is already running for you."), ephemeral=True)
        fresh = await get_vps(self.vps_id)
        if not fresh:
            return await interaction.followup.send(embed=error_embed("NOT FOUND", "Instance no longer exists."), ephemeral=True)

        os_name = interaction.data["values"][0]
        image = load_config()["images"][os_name]
        bot.deploying_users.add(interaction.user.id)
        try:
            async with deploy_semaphore():
                await vps_action(self.vps_id, "delete")
                await launch_vps(self.vps_id, image, fresh["ram_mb"], fresh["cpu"], fresh["disk_gb"])
                ip = await wait_for_ipv4(self.vps_id)
                if not ip:
                    raise RuntimeError("Reinstalled container did not get a private IPv4.")
                password = gen_password()
                await bootstrap_vps(self.vps_id, password)
                link = await create_ssh_link(self.vps_id, fresh["ssh_type"])
            await update_vps(self.vps_id, os_name=os_name, image=image, ip=ip, ssh_link=link, status="running")
            updated = await get_vps(self.vps_id)
            await interaction.followup.send(embed=vps_credentials_embed(updated, password), ephemeral=True)
        except Exception as exc:
            await update_vps(self.vps_id, status="error")
            await interaction.followup.send(
                embed=error_embed("REINSTALL FAILED", f"`{str(exc)[:500]}`\n▸ Contact support. Your instance is marked `error`."),
                ephemeral=True)
        finally:
            bot.deploying_users.discard(interaction.user.id)


class SnapshotView(OwnerView):
    def __init__(self, owner_id: int, vps_id: str):
        super().__init__(owner_id, 120)
        self.vps_id = vps_id

    @discord.ui.button(label="▸ Create Snapshot", style=discord.ButtonStyle.success)
    async def create_snap(self, interaction: discord.Interaction, _):
        await interaction.response.defer(ephemeral=True)
        try:
            limit = load_config().get("host", {}).get("max_snapshots_per_vps", 3)
            snaps = await snapshot_action(self.vps_id, "list")
            while len(snaps) >= limit:
                await snapshot_action(self.vps_id, "delete", snaps.pop(0))
            name = f"snap-{int(time.time())}"
            await snapshot_action(self.vps_id, "create", name)
        except Exception as exc:
            return await _fail(interaction, exc)
        await interaction.followup.send(
            embed=success_embed("SNAPSHOT CREATED", f"Saved `{name}`.\n▸ Max `{limit}` kept. The oldest is auto-deleted."), ephemeral=True)

    @discord.ui.button(label="◈ List Snapshots", style=discord.ButtonStyle.secondary)
    async def list_snap(self, interaction: discord.Interaction, _):
        await interaction.response.defer(ephemeral=True)
        try:
            snaps = await snapshot_action(self.vps_id, "list")
        except Exception as exc:
            return await _fail(interaction, exc)
        txt = "\n".join(f"▸ `{s}`" for s in snaps) or "No snapshots found."
        await interaction.followup.send(embed=make_embed("SNAPSHOTS", txt), ephemeral=True)

    @discord.ui.button(label="▸ Restore Latest", style=discord.ButtonStyle.primary)
    async def restore_snap(self, interaction: discord.Interaction, _):
        await interaction.response.defer(ephemeral=True)
        try:
            snaps = await snapshot_action(self.vps_id, "list")
            if not snaps:
                return await interaction.followup.send(embed=error_embed("NO SNAPSHOTS", "Create a snapshot first."), ephemeral=True)
            await snapshot_action(self.vps_id, "restore", snaps[-1])
        except Exception as exc:
            return await _fail(interaction, exc)
        await interaction.followup.send(
            embed=success_embed("RESTORED", f"Restored `{snaps[-1]}`.\n▸ Press **New SSH Link** to reopen your tunnel."), ephemeral=True)


class ConsoleModal(discord.ui.Modal, title="Run command in your VPS"):
    command = discord.ui.TextInput(
        label="Shell command",
        placeholder="Example: uname -a",
        style=discord.TextStyle.paragraph,
        required=True,
        max_length=1000,
    )

    def __init__(self, owner_id: int, vps_id: str):
        super().__init__(timeout=120)
        self.owner_id = owner_id
        self.vps_id = vps_id

    async def on_submit(self, interaction: discord.Interaction):
        if interaction.user.id != self.owner_id:
            return await interaction.response.send_message(
                embed=error_embed("NOT YOUR VPS", "This console belongs to another user."),
                ephemeral=True,
            )
        await interaction.response.defer(ephemeral=True, thinking=True)
        try:
            fresh = await get_vps(self.vps_id)
            if not fresh:
                return await interaction.followup.send(
                    embed=error_embed("NOT FOUND", "Instance no longer exists."), ephemeral=True
                )
            if fresh["status"] != "running":
                return await interaction.followup.send(
                    embed=error_embed("VPS STOPPED", "Start your VPS before using its console."),
                    ephemeral=True,
                )
            code, stdout, stderr = await exec_in(
                self.vps_id, "sh", "-lc", str(self.command.value), timeout=35
            )
            output = stdout or ""
            if stderr:
                output = (output + "\n[stderr] " + stderr).strip()
            if not output:
                output = "(command completed with no output)"
            output = output[-3500:]
            embed = make_embed(
                "VPS CONSOLE",
                f"**Instance:** `{self.vps_id}` • **Exit code:** `{code}`\n"
                f"```text\n{output.replace('```', '`\u200b``')}```",
                ACCENT_COLOR,
            )
            await interaction.followup.send(
                embed=embed, ephemeral=True, allowed_mentions=discord.AllowedMentions.none()
            )
        except Exception as exc:
            await interaction.followup.send(
                embed=error_embed("CONSOLE FAILED", f"`{str(exc)[:500]}`"), ephemeral=True
            )


class VPSControlView(OwnerView):
    def __init__(self, owner_id: int, vps_id: str):
        super().__init__(owner_id, 300)
        self.vps_id = vps_id

    async def _power(self, interaction: discord.Interaction, action: str):
        fresh = await get_vps(self.vps_id)
        if not fresh:
            return await interaction.response.send_message(embed=error_embed("NOT FOUND", "Instance no longer exists."), ephemeral=True)
        if fresh["status"] == "suspended" and action in {"start", "restart"}:
            return await interaction.response.send_message(
                embed=error_embed("SUSPENDED", "This VPS is suspended. Use `/renew` first."), ephemeral=True)
        await interaction.response.defer(ephemeral=True)
        try:
            await vps_action(self.vps_id, action)
        except Exception as exc:
            return await _fail(interaction, exc)
        await update_vps(self.vps_id, status="stopped" if action == "stop" else "running")
        note = "" if action == "stop" else "\n▸ Press **New SSH Link**. Tunnels restart with the VPS."
        await interaction.followup.send(
            embed=success_embed("POWER ACTION", f"Instance `{self.vps_id}` → `{action.upper()}` completed.{note}"), ephemeral=True)

    @discord.ui.button(label="▸ Start", style=discord.ButtonStyle.success, row=0)
    async def btn_start(self, interaction: discord.Interaction, _):
        await self._power(interaction, "start")

    @discord.ui.button(label="▪ Stop", style=discord.ButtonStyle.danger, row=0)
    async def btn_stop(self, interaction: discord.Interaction, _):
        await self._power(interaction, "stop")

    @discord.ui.button(label="◈ Restart", style=discord.ButtonStyle.primary, row=0)
    async def btn_restart(self, interaction: discord.Interaction, _):
        await self._power(interaction, "restart")

    @discord.ui.button(label="✦ New SSH Link", style=discord.ButtonStyle.secondary, row=0)
    async def btn_ssh(self, interaction: discord.Interaction, _):
        await interaction.response.defer(ephemeral=True, thinking=True)
        fresh = await get_vps(self.vps_id)
        if not fresh:
            return await interaction.followup.send(embed=error_embed("NOT FOUND", "Instance no longer exists."), ephemeral=True)
        link = await create_ssh_link(self.vps_id, fresh["ssh_type"])
        if link == SSH_UNAVAILABLE:
            return await interaction.followup.send(
                embed=error_embed("TUNNEL FAILED", "Could not open a tunnel. Is the VPS running and does it have internet?"), ephemeral=True)
        await update_vps(self.vps_id, ssh_link=link)
        await interaction.followup.send(
            embed=success_embed("SSH SESSION READY", f"▸ Mode: `{fresh['ssh_type']}`\n```\n{link}\n```"), ephemeral=True)

    @discord.ui.button(label="↻ Refresh", style=discord.ButtonStyle.secondary, row=0)
    async def btn_refresh(self, interaction: discord.Interaction, _):
        await interaction.response.defer()
        fresh = await get_vps(self.vps_id)
        if not fresh:
            return await interaction.followup.send(embed=error_embed("NOT FOUND", "Instance no longer exists."), ephemeral=True)
        try:
            live = await get_live_stats(self.vps_id)
        except Exception:
            live = None
        await interaction.edit_original_response(embed=vps_dashboard_embed(fresh, live), view=self)

    @discord.ui.button(label="◇ Credentials", style=discord.ButtonStyle.secondary, row=1)
    async def btn_creds(self, interaction: discord.Interaction, _):
        fresh = await get_vps(self.vps_id)
        if not fresh:
            return await interaction.response.send_message(embed=error_embed("NOT FOUND", "Instance no longer exists."), ephemeral=True)
        await interaction.response.send_message(embed=vps_credentials_embed(fresh), ephemeral=True)

    @discord.ui.button(label="⟳ Reset Password", style=discord.ButtonStyle.secondary, row=1)
    async def btn_reset_pw(self, interaction: discord.Interaction, _):
        await interaction.response.defer(ephemeral=True)
        password = gen_password()
        try:
            await set_root_password(self.vps_id, password)
        except Exception as exc:
            return await _fail(interaction, exc)
        await interaction.followup.send(
            embed=success_embed("PASSWORD RESET", f"▸ New root password: ||`{password}`||\n▸ Not stored anywhere. Save it now."), ephemeral=True)

    @discord.ui.button(label="▣ Snapshots", style=discord.ButtonStyle.secondary, row=1)
    async def btn_snaps(self, interaction: discord.Interaction, _):
        await interaction.response.send_message(
            embed=make_embed("SNAPSHOT MANAGER", f"▸ Instance: `{self.vps_id}`"),
            view=SnapshotView(self.owner_id, self.vps_id), ephemeral=True)

    @discord.ui.button(label="▸ Reinstall OS", style=discord.ButtonStyle.danger, row=1)
    async def btn_reinstall(self, interaction: discord.Interaction, _):
        await interaction.response.send_message(
            embed=warn_embed("REINSTALL OS", "All data and snapshots of this VPS will be erased! Pick a new OS:"),
            view=ReinstallOSView(self.owner_id, self.vps_id), ephemeral=True)

    @discord.ui.button(label="⌘ Console", style=discord.ButtonStyle.secondary, row=2)
    async def btn_console(self, interaction: discord.Interaction, _):
        fresh = await get_vps(self.vps_id)
        if not fresh:
            return await interaction.response.send_message(
                embed=error_embed("NOT FOUND", "Instance no longer exists."), ephemeral=True
            )
        if fresh["status"] != "running":
            return await interaction.response.send_message(
                embed=error_embed("VPS STOPPED", "Start your VPS before opening its console."),
                ephemeral=True,
            )
        await interaction.response.send_modal(ConsoleModal(self.owner_id, self.vps_id))

    @discord.ui.button(label="✕ Delete", style=discord.ButtonStyle.danger, row=2)
    async def btn_delete(self, interaction: discord.Interaction, _):
        await interaction.response.send_message(
            embed=warn_embed("CONFIRM DELETION", f"Are you sure you want to delete `{self.vps_id}`?"),
            view=ConfirmDeleteView(self.owner_id, self.vps_id), ephemeral=True)


class InstancePickerView(OwnerView):
    def __init__(self, cog, owner_id: int, instances: list[dict]):
        super().__init__(owner_id, 120)
        self.cog = cog
        opts = [
            discord.SelectOption(label=v["vps_id"], description=f"{v['plan_name']} • {v['status']}", value=v["vps_id"])
            for v in instances[:25]
        ]
        sel = discord.ui.Select(placeholder="▸ Choose an instance...", options=opts)
        sel.callback = self.on_pick
        self.add_item(sel)

    async def on_pick(self, interaction: discord.Interaction):
        await self.cog.send_vps_panel(interaction, interaction.user, interaction.data["values"][0])


class VPSControlCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.expiry_loop.start()
        self.sync_loop.start()

    def cog_unload(self):
        self.expiry_loop.cancel()
        self.sync_loop.cancel()

    async def send_vps_panel(self, target, user: discord.abc.User, vps_id: str | None = None):
        is_inter = isinstance(target, discord.Interaction)
        if is_inter:
            await target.response.defer(ephemeral=True)

        async def reply(**kw):
            if is_inter:
                await target.followup.send(ephemeral=True, **kw)
            else:
                await target.send(**kw)

        instances = await get_user_vps(user.id)
        if not instances:
            return await reply(embed=error_embed("NO INSTANCES", "You have no active VPS.\n▸ Use `/deploy` or `!deploy` to create one."))

        if vps_id is None and len(instances) > 1:
            return await reply(
                embed=make_embed("YOUR INSTANCES", f"▸ You own `{len(instances)}` instances. Pick one:"),
                view=InstancePickerView(self, user.id, instances))

        vps = next((v for v in instances if v["vps_id"] == vps_id), instances[0]) if vps_id else instances[0]
        try:
            live = await get_live_stats(vps["vps_id"])
        except Exception:
            live = None
        await reply(embed=vps_dashboard_embed(vps, live), view=VPSControlView(user.id, vps["vps_id"]))

    @commands.hybrid_command(name="myvps", aliases=["vps", "manage"], description="Manage your VPS")
    async def myvps(self, ctx: commands.Context, vps_id: str | None = None):
        await self.send_vps_panel(ctx.interaction or ctx, ctx.author, vps_id)

    @commands.hybrid_command(name="renew", description="Renew your VPS expiry")
    async def renew(self, ctx: commands.Context, vps_id: str | None = None):
        instances = await get_user_vps(ctx.author.id)
        if not instances:
            return await ctx.send(embed=error_embed("NO INSTANCES", "You do not own a VPS."))
        vps = next((v for v in instances if v["vps_id"] == vps_id), instances[0]) if vps_id else instances[0]
        cfg = load_config()
        plan = cfg["plans"].get(vps["plan_key"])
        user_data = await get_user(ctx.author.id)
        if plan and user_data["available"] < plan["invites"]:
            return await ctx.send(embed=error_embed(
                "CANNOT RENEW", f"Requires `{plan['invites']}` invites; you currently have `{user_data['available']}`."))
        new_exp = int(time.time()) + cfg["settings"]["vps_expiry_days"] * 86400
        try:
            if vps["status"] in {"suspended", "stopped"}:
                await vps_action(vps["vps_id"], "start")
        except Exception as exc:
            return await ctx.send(embed=error_embed("RENEW FAILED", f"`{str(exc)[:400]}`"))
        await update_vps(vps["vps_id"], expires_at=new_exp, warned_expiry=0, status="running")
        await ctx.send(embed=success_embed("RENEWED", f"Instance `{vps['vps_id']}` renewed until <t:{new_exp}:F>."))

    # ------------------------------------------------------------------ #
    @tasks.loop(minutes=15)
    async def expiry_loop(self):
        try:
            cfg = load_config()
            now = int(time.time())
            grace = cfg["settings"].get("suspend_grace_days", 7) * 86400
            for vps in await get_all_vps():
                try:
                    vid = vps["vps_id"]
                    if now >= vps["expires_at"] + grace:
                        try:
                            await vps_action(vid, "delete")
                        except Exception:
                            continue
                        await delete_vps_record(vid)
                        await _dm(self.bot, vps["owner_id"], error_embed(
                            "VPS TERMINATED", f"`{vid}` exceeded the grace period and was deleted."))
                    elif now >= vps["expires_at"] and vps["status"] != "suspended":
                        try:
                            await vps_action(vid, "stop")
                        except Exception:
                            pass
                        await update_vps(vid, status="suspended")
                        await _dm(self.bot, vps["owner_id"], warn_embed(
                            "VPS SUSPENDED", f"`{vid}` expired. Use `/renew` within `{cfg['settings']['suspend_grace_days']}d`."))
                    elif vps["expires_at"] - now <= 3 * 86400 and not vps["warned_expiry"] and vps["status"] != "suspended":
                        await update_vps(vid, warned_expiry=1)
                        await _dm(self.bot, vps["owner_id"], warn_embed(
                            "EXPIRY REMINDER", f"`{vid}` expires <t:{vps['expires_at']}:R>. Run `/renew`."))
                except Exception as exc:
                    print(f"expiry_loop error on {vps.get('vps_id')}: {exc}")
        except Exception as exc:
            print(f"expiry_loop error: {exc}")

    @tasks.loop(minutes=5)
    async def sync_loop(self):
        """Keep DB status aligned with what Incus actually reports."""
        try:
            live = await list_instances()
            busy = {str(u) for u in self.bot.deploying_users}
            for v in await get_all_vps():
                if v["status"] == "suspended" or v["owner_id"] in busy:
                    continue
                inst = live.get(v["vps_id"])
                if inst is None:
                    new = "missing"
                else:
                    new = "running" if (inst.get("status") or "").lower() == "running" else "stopped"
                if new != v["status"]:
                    await update_vps(v["vps_id"], status=new)
        except Exception as exc:
            print(f"sync_loop error: {exc}")

    @expiry_loop.before_loop
    @sync_loop.before_loop
    async def _wait_ready(self):
        await self.bot.wait_until_ready()


async def setup(bot):
    await bot.add_cog(VPSControlCog(bot))

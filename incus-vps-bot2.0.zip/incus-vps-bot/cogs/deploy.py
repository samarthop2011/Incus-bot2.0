import time

import discord
from discord.ext import commands

from utils.db import add_spent_invites, get_user, get_user_vps, load_config, set_last_deploy
from utils.embeds import (
    build_host_embed,
    error_embed,
    fmt_gb,
    make_embed,
    plans_embed,
    progress_embed,
    success_embed,
    vps_credentials_embed,
    warn_embed,
)
from utils.provision import STEPS, provision_vps


async def deploy_blocker(uid: int, plan: dict | None = None) -> discord.Embed | None:
    """Return an error embed if the user may not deploy right now, else None."""
    cfg = load_config()
    if cfg["bot"].get("maintenance_mode"):
        return warn_embed("MAINTENANCE MODE", "Deployments are temporarily paused for maintenance.")
    user = await get_user(uid)
    if user["blacklisted"]:
        return error_embed("BLACKLISTED", f"Reason: `{user['blacklist_reason'] or 'Policy violation'}`")
    existing = await get_user_vps(uid)
    limit = cfg["settings"]["max_vps_per_user"]
    if len(existing) >= limit:
        return error_embed("VPS LIMIT", f"You already have `{len(existing)}/{limit}` VPS.\n▸ Manage it with `/myvps`.")
    last = user["last_deploy_at"]
    if last:
        rem = cfg["settings"]["deploy_cooldown_seconds"] - (int(time.time()) - last)
        if rem > 0:
            return warn_embed("COOLDOWN ACTIVE", f"Wait `{rem}s` before deploying again.")
    if plan and user["available"] < plan["invites"]:
        return error_embed(
            "INSUFFICIENT INVITES",
            f"**{plan['name']}** needs `{plan['invites']}` invites, you have `{user['available']}`.",
        )
    return None


async def execute_deploy(bot, interaction: discord.Interaction, plan_key: str, os_name: str,
                         image: str, ssh_type: str, custom_specs=None):
    cfg = load_config()
    uid = interaction.user.id
    plan = cfg["plans"][plan_key]

    async def show(embed: discord.Embed):
        try:
            await interaction.edit_original_response(embed=embed, view=None)
        except discord.HTTPException:
            pass

    if uid in bot.deploying_users:
        return await show(warn_embed("IN PROGRESS", "You already have a deployment running. Please wait."))

    bot.deploying_users.add(uid)
    try:
        blocker = await deploy_blocker(uid, plan)
        if blocker:
            return await show(blocker)

        ram_mb, cpu, disk_gb = custom_specs if custom_specs else (plan["ram_mb"], plan["cpu"], plan["disk_gb"])
        header = (
            f"▸ Plan: **{plan['name']}** (`{fmt_gb(ram_mb)}GB / {cpu}C / {disk_gb}GB`)\n"
            f"▸ OS: `{os_name}`  |  SSH: `{ssh_type}`"
        )

        async def progress(step: int, note: str = ""):
            await show(progress_embed("PROVISIONING VPS", STEPS, step, header + (f"\n{note}" if note else "")))

        await progress(0)
        record, password = await provision_vps(
            uid, plan_key, plan["name"], ram_mb, cpu, disk_gb, os_name, image, ssh_type, progress
        )

        now = int(time.time())
        await set_last_deploy(uid, now)
        if cfg["settings"].get("deduct_invites_on_deploy", False):
            await add_spent_invites(uid, plan["invites"])

        await show(success_embed("DEPLOYMENT COMPLETE", f"▸ Instance `{record['vps_id']}` is live.\n▸ Credentials are below (and in your DMs)."))
        cred = vps_credentials_embed(record, password)
        await interaction.followup.send(embed=cred, ephemeral=True)
        try:
            await interaction.user.send(embed=cred)
        except discord.HTTPException:
            await interaction.followup.send(
                embed=warn_embed("DMS CLOSED", "Could not DM you. Save the password now. It is not stored."),
                ephemeral=True,
            )

        log_ch_id = cfg["settings"].get("log_channel_id", 0)
        if log_ch_id and interaction.guild:
            log_ch = interaction.guild.get_channel(int(log_ch_id))
            if log_ch:
                await log_ch.send(embed=make_embed(
                    "VPS DEPLOYED",
                    f"▸ Owner: {interaction.user.mention} (`{uid}`)\n"
                    f"▸ Instance: `{record['vps_id']}`\n"
                    f"▸ Plan: **{plan['name']}** | OS: `{os_name}`",
                ))
    except Exception as exc:
        role_id = cfg["settings"].get("support_role_id", 0)
        sup = f"\n▸ Contact <@&{role_id}>" if role_id else ""
        await show(error_embed("DEPLOYMENT FAILED", f"`{str(exc)[:600]}`{sup}"))
    finally:
        bot.deploying_users.discard(uid)


class CustomSpecsModal(discord.ui.Modal, title="Enterprise Ultimate - Custom Specs"):
    ram_gb = discord.ui.TextInput(label="RAM (in GB)", placeholder="e.g. 32", min_length=1, max_length=3)
    cpu = discord.ui.TextInput(label="vCPU Cores", placeholder="e.g. 8", min_length=1, max_length=2)
    disk_gb = discord.ui.TextInput(label="SSD Storage (in GB)", placeholder="e.g. 150", min_length=2, max_length=4)

    def __init__(self, bot, plan_key: str):
        super().__init__()
        self.bot = bot
        self.plan_key = plan_key

    async def on_submit(self, interaction: discord.Interaction):
        limits = load_config()["settings"]["custom_plan_limits"]
        try:
            r_gb = int(self.ram_gb.value.strip())
            c = int(self.cpu.value.strip())
            d_gb = int(self.disk_gb.value.strip())
        except ValueError:
            return await interaction.response.send_message(
                embed=error_embed("INVALID INPUT", "All custom fields must be whole numbers."), ephemeral=True)
        max_r = limits["max_ram_mb"] // 1024
        if not (1 <= r_gb <= max_r and 1 <= c <= limits["max_cpu"] and 10 <= d_gb <= limits["max_disk_gb"]):
            return await interaction.response.send_message(
                embed=error_embed("OUT OF RANGE",
                                  f"Limits: `1-{max_r} GB RAM`, `1-{limits['max_cpu']} vCores`, `10-{limits['max_disk_gb']} GB SSD`."),
                ephemeral=True)
        view = OSSelectView(self.bot, self.plan_key, (r_gb * 1024, c, d_gb))
        await interaction.response.send_message(
            embed=make_embed("SELECT OS", f"▸ Custom Specs: `{r_gb}GB / {c} vCore / {d_gb}GB SSD`\n▸ Choose Operating System:"),
            view=view, ephemeral=True)


class SSHSelectView(discord.ui.View):
    def __init__(self, bot, plan_key: str, os_name: str, image: str, custom_specs=None):
        super().__init__(timeout=180)
        self.bot, self.plan_key, self.os_name, self.image, self.custom_specs = bot, plan_key, os_name, image, custom_specs

    async def _go(self, interaction: discord.Interaction, ssh_type: str):
        await interaction.response.defer(ephemeral=True, thinking=True)
        await execute_deploy(self.bot, interaction, self.plan_key, self.os_name, self.image, ssh_type, self.custom_specs)

    @discord.ui.button(label="▸ Deploy with sshx", style=discord.ButtonStyle.success)
    async def deploy_sshx(self, interaction: discord.Interaction, _):
        await self._go(interaction, "sshx")

    @discord.ui.button(label="▸ Deploy with tmate", style=discord.ButtonStyle.primary)
    async def deploy_tmate(self, interaction: discord.Interaction, _):
        await self._go(interaction, "tmate")


class OSSelectView(discord.ui.View):
    def __init__(self, bot, plan_key: str, custom_specs=None):
        super().__init__(timeout=180)
        self.bot, self.plan_key, self.custom_specs = bot, plan_key, custom_specs
        options = [discord.SelectOption(label=f"▸ {name}", value=name) for name in load_config()["images"]]
        sel = discord.ui.Select(placeholder="▸ Select Operating System...", options=options)
        sel.callback = self.on_os
        self.add_item(sel)

    async def on_os(self, interaction: discord.Interaction):
        os_name = interaction.data["values"][0]
        image = load_config()["images"][os_name]
        view = SSHSelectView(self.bot, self.plan_key, os_name, image, self.custom_specs)
        await interaction.response.send_message(
            embed=make_embed(
                "SELECT SSH TYPE",
                f"▸ OS Selected: **{os_name}**\n\n"
                "┌ `sshx`  - browser-based terminal link\n"
                "└ `tmate` - direct SSH terminal session\n\n"
                "▸ Both are outbound tunnels, so no public IP is needed.",
            ),
            view=view, ephemeral=True)


class PlanSelectView(discord.ui.View):
    def __init__(self, bot, available_invites: int):
        super().__init__(timeout=180)
        self.bot, self.invites = bot, available_invites
        options = []
        for key, p in load_config()["plans"].items():
            mark = "◆" if available_invites >= p["invites"] else "◇"
            desc = ("Custom RAM | Custom CPU | Custom SSD" if p.get("custom")
                    else f"{fmt_gb(p['ram_mb'])}GB RAM | {p['cpu']} vCore | {p['disk_gb']}GB SSD")
            options.append(discord.SelectOption(label=f"{mark} {p['name']} ({p['invites']} Inv)", description=desc, value=key))
        sel = discord.ui.Select(placeholder="▸ Choose a VPS plan...", options=options)
        sel.callback = self.on_plan
        self.add_item(sel)

    async def on_plan(self, interaction: discord.Interaction):
        plan_key = interaction.data["values"][0]
        plan = load_config()["plans"][plan_key]
        if self.invites < plan["invites"]:
            return await interaction.response.send_message(
                embed=error_embed("LOCKED PLAN", f"**{plan['name']}** requires `{plan['invites']}` invites. You have `{self.invites}`."),
                ephemeral=True)
        if plan.get("custom"):
            return await interaction.response.send_modal(CustomSpecsModal(self.bot, plan_key))
        await interaction.response.send_message(
            embed=make_embed("SELECT OS", f"▸ Selected Plan: **{plan['name']}**\n▸ Choose an OS image below:"),
            view=OSSelectView(self.bot, plan_key), ephemeral=True)


async def start_deploy_flow(bot, interaction: discord.Interaction):
    blocker = await deploy_blocker(interaction.user.id)
    if blocker:
        return await interaction.response.send_message(embed=blocker, ephemeral=True)
    user = await get_user(interaction.user.id)
    await interaction.response.send_message(
        embed=make_embed("SELECT PLAN", f"▸ Available Invites: `{user['available']}`\n▸ Pick a plan unlocked by your invites:"),
        view=PlanSelectView(bot, user["available"]), ephemeral=True)


class DeployPanelView(discord.ui.View):
    def __init__(self, bot):
        super().__init__(timeout=None)
        self.bot = bot

    @discord.ui.button(label="◆ Deploy VPS", style=discord.ButtonStyle.primary, custom_id="panel_deploy_btn")
    async def btn_deploy(self, interaction: discord.Interaction, _):
        await start_deploy_flow(self.bot, interaction)

    @discord.ui.button(label="◈ My Instances", style=discord.ButtonStyle.secondary, custom_id="panel_myvps_btn")
    async def btn_myvps(self, interaction: discord.Interaction, _):
        cog = self.bot.get_cog("VPSControlCog")
        if cog:
            await cog.send_vps_panel(interaction, interaction.user)

    @discord.ui.button(label="▸ Plans", style=discord.ButtonStyle.secondary, custom_id="panel_plans_btn")
    async def btn_plans(self, interaction: discord.Interaction, _):
        await interaction.response.send_message(embed=plans_embed(load_config()), ephemeral=True)

    @discord.ui.button(label="✦ My Invites", style=discord.ButtonStyle.secondary, custom_id="panel_invites_btn")
    async def btn_invites(self, interaction: discord.Interaction, _):
        u = await get_user(interaction.user.id)
        desc = (
            f"┌─ **Invite Breakdown**\n"
            f"│  ├ Regular: `{u['regular_invites']}`\n"
            f"│  ├ Bonus: `{u['bonus_invites']}`\n"
            f"│  ├ Leaves: `-{u['leave_invites']}`\n"
            f"│  ├ Fake: `-{u['fake_invites']}`\n"
            f"│  ├ Spent: `-{u['spent_invites']}`\n"
            f"│  └ **Available: `{u['available']}`**"
        )
        await interaction.response.send_message(embed=make_embed("YOUR INVITES", desc), ephemeral=True)

    @discord.ui.button(label="◇ Status", style=discord.ButtonStyle.secondary, custom_id="panel_status_btn")
    async def btn_status(self, interaction: discord.Interaction, _):
        await interaction.response.defer(ephemeral=True)
        await interaction.followup.send(embed=await build_host_embed(False), ephemeral=True)


class DeployCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.hybrid_command(name="panel", description="Post the permanent VPS Deploy Panel (Admin)")
    @commands.has_permissions(administrator=True)
    async def panel(self, ctx: commands.Context):
        await ctx.send(embed=plans_embed(load_config()), view=DeployPanelView(self.bot))

    @commands.hybrid_command(name="deploy", aliases=["create"], description="Deploy a new VPS")
    async def deploy(self, ctx: commands.Context):
        if ctx.interaction:
            await start_deploy_flow(self.bot, ctx.interaction)
        else:
            await ctx.send(embed=plans_embed(load_config()), view=DeployPanelView(self.bot))

    @commands.hybrid_command(name="plans", description="View all VPS invite plans")
    async def plans(self, ctx: commands.Context):
        await ctx.send(embed=plans_embed(load_config()))


async def setup(bot):
    await bot.add_cog(DeployCog(bot))

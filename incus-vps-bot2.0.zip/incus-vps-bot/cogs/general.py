import platform

import discord
from discord.ext import commands

from utils.db import load_config
from utils.embeds import ACCENT_COLOR, build_host_embed, make_embed


class GeneralCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.hybrid_command(name="help", description="Show all bot commands")
    async def help_cmd(self, ctx: commands.Context):
        p = load_config()["bot"].get("prefix", "!")
        desc = (
            f"▸ Both **Slash (`/`)** and **Prefix (`{p}`)** commands work.\n\n"
            f"┌─ **VPS**\n"
            f"│  ├ `{p}deploy` - launch the deployment wizard\n"
            f"│  ├ `{p}plans` - view all invite plans\n"
            f"│  ├ `{p}myvps` - power, console, SSH link, password, snapshots, reinstall\n"
            f"│  ├ `{p}renew` - renew your VPS\n"
            f"│  └ `{p}status` - host capacity and health\n\n"
            f"┌─ **Invites**\n"
            f"│  ├ `{p}invites` - your invite stats\n"
            f"│  ├ `{p}leaderboard` - top inviters\n"
            f"│  └ `{p}whoinvited` - who invited a member\n\n"
            f"┌─ **Administration**\n"
            f"│  ├ `{p}panel` - post the permanent deploy panel\n"
            f"│  ├ `{p}admin` - stats, host, vps, info, extend, addinv, blacklist, suspend, "
            f"unsuspend, terminate, forcevps, maintenance, broadcast, purge\n"
            f"│  └ `{p}ping` / `{p}botinfo` - bot diagnostics"
        )
        await ctx.send(embed=make_embed("COMMAND DIRECTORY", desc, ACCENT_COLOR))

    @commands.hybrid_command(name="status", description="Host capacity and health")
    async def status(self, ctx: commands.Context):
        await ctx.defer()
        await ctx.send(embed=await build_host_embed(admin=False))

    @commands.hybrid_command(name="botinfo", aliases=["about"], description="Show bot runtime information")
    async def botinfo(self, ctx: commands.Context):
        embed = make_embed(
            "BOT INFORMATION",
            f"**Python:** `{platform.python_version()}`\n"
            f"**discord.py:** `{discord.__version__}`\n"
            f"**Servers:** `{len(self.bot.guilds)}`\n"
            f"**Latency:** `{round(self.bot.latency * 1000)} ms`\n"
            f"**Prefix:** `{load_config()['bot'].get('prefix', '!')}`",
            ACCENT_COLOR,
        )
        await ctx.send(embed=embed)

    @commands.hybrid_command(name="ping", description="Check bot latency")
    async def ping(self, ctx: commands.Context):
        ms = round(self.bot.latency * 1000)
        await ctx.send(embed=make_embed("SYSTEM PING", f"◆ Gateway Latency: `{ms} ms`", ACCENT_COLOR))


async def setup(bot):
    await bot.add_cog(GeneralCog(bot))

import time
from typing import Literal

import discord
from discord import app_commands
from discord.ext import commands

from utils.db import (
    add_bonus_invites,
    delete_vps_record,
    get_all_vps,
    get_global_stats,
    get_vps,
    load_config,
    save_config,
    set_blacklist,
    update_vps,
)
from utils.embeds import (
    ACCENT_COLOR,
    build_host_embed,
    error_embed,
    make_embed,
    success_embed,
    vps_credentials_embed,
    vps_dashboard_embed,
)
from utils.incus import get_live_stats, list_instances, preflight, vps_action
from utils.provision import provision_vps


def is_hosting_admin():
    async def predicate(ctx: commands.Context):
        if await ctx.bot.is_owner(ctx.author):
            return True
        if not ctx.guild:
            return False
        perms = getattr(ctx.author, "guild_permissions", None)
        if perms and perms.administrator:
            return True
        admin_roles = {int(rid) for rid in load_config()["settings"].get("admin_role_ids", [])}
        return any(r.id in admin_roles for r in getattr(ctx.author, "roles", []))
    return commands.check(predicate)


class AdminCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.hybrid_group(name="admin", description="Hosting administration commands")
    @app_commands.default_permissions(administrator=True)
    @is_hosting_admin()
    async def admin(self, ctx: commands.Context):
        if ctx.invoked_subcommand is None:
            await ctx.send(embed=make_embed(
                "ADMIN PANEL",
                "`stats` `host` `vps` `info` `extend` `addinv` `blacklist` `unblacklist` "
                "`suspend` `unsuspend` `terminate` `forcevps` `maintenance` `broadcast` `purge`"))

    @admin.command(name="stats", description="Bot + VPS statistics")
    @is_hosting_admin()
    async def stats(self, ctx: commands.Context):
        gs = await get_global_stats()
        cfg = load_config()
        desc = (
            f"┌─ **Summary**\n"
            f"│  ├ Total VPS: `{gs['total_vps']}`\n"
            f"│  ├ Running: `{gs['running']}` • Stopped: `{gs['stopped']}` • Suspended: `{gs['suspended']}` • Other: `{gs['other']}`\n"
            f"│  ├ Tracked Users: `{gs['users']}`\n"
            f"│  └ Maintenance: `{cfg['bot']['maintenance_mode']}`"
        )
        await ctx.send(embed=make_embed("ANALYTICS", desc, ACCENT_COLOR))

    @admin.command(name="host", description="Local host health, capacity and Incus checks")
    @is_hosting_admin()
    async def host(self, ctx: commands.Context):
        await ctx.defer()
        embed = await build_host_embed(admin=True)
        issues = await preflight()
        if issues:
            embed.add_field(name="⚠ Host check", value="\n".join(f"▸ {i}" for i in issues)[:1000], inline=False)
        await ctx.send(embed=embed)

    @admin.command(name="vps", description="List all VPS instances")
    @is_hosting_admin()
    async def vps(self, ctx: commands.Context):
        rows = await get_all_vps()
        lines = [
            f"`{v['vps_id']}` <@{v['owner_id']}> • {v['plan_name']} • `{v['status']}` • <t:{v['expires_at']}:R>"
            for v in rows[:25]
        ]
        extra = f"\n… and `{len(rows) - 25}` more" if len(rows) > 25 else ""
        await ctx.send(embed=make_embed(f"ALL VPS ({len(rows)})", "\n".join(lines) + extra if lines else "No VPS yet."))

    @admin.command(name="info", description="Inspect a VPS")
    @is_hosting_admin()
    async def info(self, ctx: commands.Context, vps_id: str):
        v = await get_vps(vps_id)
        if not v:
            return await ctx.send(embed=error_embed("NOT FOUND", f"`{vps_id}` not found."))
        try:
            live = await get_live_stats(vps_id)
        except Exception:
            live = None
        embed = vps_dashboard_embed(v, live)
        embed.add_field(name="Owner", value=f"<@{v['owner_id']}>", inline=True)
        await ctx.send(embed=embed)

    @admin.command(name="extend", description="Extend a VPS by N days")
    @is_hosting_admin()
    async def extend(self, ctx: commands.Context, vps_id: str, days: int):
        v = await get_vps(vps_id)
        if not v:
            return await ctx.send(embed=error_embed("NOT FOUND", f"`{vps_id}` not found."))
        new_exp = v["expires_at"] + days * 86400
        fields = {"expires_at": new_exp, "warned_expiry": 0}
        if v["status"] == "suspended" and new_exp > int(time.time()):
            try:
                await vps_action(vps_id, "start")
                fields["status"] = "running"
            except Exception as exc:
                return await ctx.send(embed=error_embed("START FAILED", f"`{str(exc)[:400]}`"))
        await update_vps(vps_id, **fields)
        await ctx.send(embed=success_embed("EXTENDED", f"`{vps_id}` now expires <t:{new_exp}:F>."))

    @admin.command(name="addinv", description="Add or subtract bonus invites")
    @is_hosting_admin()
    async def addinv(self, ctx: commands.Context, member: discord.Member, amount: int):
        await add_bonus_invites(member.id, amount)
        await ctx.send(embed=success_embed("INVITES UPDATED", f"Adjusted bonus invites for {member.mention} by `{amount:+d}`."))

    @admin.command(name="blacklist", description="Blacklist a user from deploying")
    @is_hosting_admin()
    async def blacklist(self, ctx: commands.Context, member: discord.Member, *, reason: str = "Abuse"):
        await set_blacklist(member.id, 1, reason)
        await ctx.send(embed=success_embed("USER BLACKLISTED", f"{member.mention} blocked. Reason: `{reason}`"))

    @admin.command(name="unblacklist", description="Remove user from blacklist")
    @is_hosting_admin()
    async def unblacklist(self, ctx: commands.Context, member: discord.Member):
        await set_blacklist(member.id, 0, "")
        await ctx.send(embed=success_embed("USER UNBLACKLISTED", f"{member.mention} can deploy again."))

    @admin.command(name="suspend", description="Force suspend a VPS")
    @is_hosting_admin()
    async def suspend(self, ctx: commands.Context, vps_id: str):
        if not await get_vps(vps_id):
            return await ctx.send(embed=error_embed("NOT FOUND", f"`{vps_id}` not found."))
        try:
            await vps_action(vps_id, "stop")
        except Exception as exc:
            return await ctx.send(embed=error_embed("STOP FAILED", f"`{str(exc)[:400]}`"))
        await update_vps(vps_id, status="suspended")
        await ctx.send(embed=success_embed("SUSPENDED", f"`{vps_id}` has been suspended."))

    @admin.command(name="unsuspend", description="Start a suspended VPS")
    @is_hosting_admin()
    async def unsuspend(self, ctx: commands.Context, vps_id: str):
        if not await get_vps(vps_id):
            return await ctx.send(embed=error_embed("NOT FOUND", f"`{vps_id}` not found."))
        try:
            await vps_action(vps_id, "start")
        except Exception as exc:
            return await ctx.send(embed=error_embed("START FAILED", f"`{str(exc)[:400]}`"))
        await update_vps(vps_id, status="running")
        await ctx.send(embed=success_embed("UNSUSPENDED", f"`{vps_id}` is running again."))

    @admin.command(name="terminate", description="Force delete a VPS")
    @is_hosting_admin()
    async def terminate(self, ctx: commands.Context, vps_id: str):
        if not await get_vps(vps_id):
            return await ctx.send(embed=error_embed("NOT FOUND", f"`{vps_id}` not found."))
        try:
            await vps_action(vps_id, "delete")
        except Exception as exc:
            return await ctx.send(embed=error_embed("DELETE FAILED", f"`{str(exc)[:400]}`"))
        await delete_vps_record(vps_id)
        await ctx.send(embed=success_embed("TERMINATED", f"`{vps_id}` permanently deleted."))

    @admin.command(name="forcevps", description="Deploy a VPS for a user (bypasses invites)")
    @is_hosting_admin()
    async def forcevps(self, ctx: commands.Context, member: discord.Member, plan_key: str,
                       ssh_type: Literal["sshx", "tmate"] = "sshx", os_name: str = "",
                       ram_gb: int = 0, cpu: int = 0, disk_gb: int = 0):
        cfg = load_config()
        plan = cfg["plans"].get(plan_key)
        if not plan:
            return await ctx.send(embed=error_embed("INVALID PLAN", f"Valid keys: {', '.join(cfg['plans'])}"))
        if plan.get("custom"):
            if not (ram_gb and cpu and disk_gb):
                return await ctx.send(embed=error_embed("CUSTOM PLAN", "Provide `ram_gb`, `cpu` and `disk_gb`."))
            ram_mb, c, d = ram_gb * 1024, cpu, disk_gb
        else:
            ram_mb, c, d = plan["ram_mb"], plan["cpu"], plan["disk_gb"]
        os_name = os_name or next(iter(cfg["images"]))
        image = cfg["images"].get(os_name)
        if not image:
            return await ctx.send(embed=error_embed("INVALID OS", f"Valid: {', '.join(cfg['images'])}"))

        await ctx.defer()
        try:
            record, pw = await provision_vps(member.id, plan_key, plan["name"], ram_mb, c, d, os_name, image, ssh_type)
        except Exception as exc:
            return await ctx.send(embed=error_embed("DEPLOY FAILED", f"`{str(exc)[:500]}`"))

        cred = vps_credentials_embed(record, pw)
        delivered_to = None
        for target in (member, ctx.author):
            try:
                await target.send(embed=cred)
                delivered_to = target
                break
            except discord.HTTPException:
                continue
        note = f"Credentials sent to {delivered_to.mention}." if delivered_to else "Could not DM anyone: password is lost; use Reset Password."
        await ctx.send(embed=success_embed("FORCE DEPLOYED", f"Created `{record['vps_id']}` for {member.mention}.\n▸ {note}"))

    @admin.command(name="maintenance", description="Toggle deployment maintenance mode")
    @is_hosting_admin()
    async def maintenance(self, ctx: commands.Context, state: bool):
        cfg = load_config()
        cfg["bot"]["maintenance_mode"] = state
        save_config(cfg)
        await ctx.send(embed=success_embed("MAINTENANCE", f"Maintenance mode set to `{state}`."))

    @admin.command(name="purge", description="Delete DB records for VPSes that no longer exist in Incus")
    @is_hosting_admin()
    async def purge(self, ctx: commands.Context):
        await ctx.defer()
        try:
            live = await list_instances()
        except Exception as exc:
            return await ctx.send(embed=error_embed("INCUS ERROR", f"`{str(exc)[:400]}`"))
        removed = []
        for v in await get_all_vps():
            if v["vps_id"] not in live:
                await delete_vps_record(v["vps_id"])
                removed.append(v["vps_id"])
        txt = "\n".join(f"▸ `{r}`" for r in removed[:30]) or "Nothing to purge."
        await ctx.send(embed=success_embed("PURGE COMPLETE", f"Removed `{len(removed)}` stale records.\n{txt}"))

    @admin.command(name="broadcast", description="DM all VPS owners")
    @is_hosting_admin()
    async def broadcast(self, ctx: commands.Context, *, message: str):
        import asyncio
        await ctx.defer()
        owners = {v["owner_id"] for v in await get_all_vps()}
        sent = 0
        for oid in owners:
            try:
                u = self.bot.get_user(int(oid)) or await self.bot.fetch_user(int(oid))
                await u.send(embed=make_embed("HOSTING ANNOUNCEMENT", message, ACCENT_COLOR))
                sent += 1
            except (discord.HTTPException, discord.NotFound):
                pass
            await asyncio.sleep(0.5)
        await ctx.send(embed=success_embed("BROADCAST COMPLETE", f"Delivered to `{sent}/{len(owners)}` VPS owners."))


async def setup(bot):
    await bot.add_cog(AdminCog(bot))

import discord
from discord.ext import commands

from utils.db import get_inviter_of, get_leaderboard, get_user, load_config
from utils.embeds import ACCENT_COLOR, make_embed


class InvitesCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.hybrid_command(name="invites", aliases=["inv", "i"], description="Check your invite stats")
    async def invites(self, ctx: commands.Context, member: discord.Member | None = None):
        target = member or ctx.author
        u = await get_user(target.id)
        cfg = load_config()
        next_plan = next((p for p in cfg["plans"].values() if p["invites"] > u["available"]), None)
        next_txt = (
            f"▸ Next Tier: **{next_plan['name']}** (`{next_plan['invites'] - u['available']}` more invites)"
            if next_plan else "▸ Highest tier unlocked!"
        )
        desc = (
            f"▸ User: {target.mention}\n\n"
            f"┌─ **Invite Breakdown**\n"
            f"│  ├ Regular: `{u['regular_invites']}`\n"
            f"│  ├ Bonus: `{u['bonus_invites']}`\n"
            f"│  ├ Leaves: `-{u['leave_invites']}`\n"
            f"│  ├ Fake: `-{u['fake_invites']}`\n"
            f"│  ├ Spent: `-{u['spent_invites']}`\n"
            f"│  └ **Available: `{u['available']}`**\n\n"
            f"{next_txt}"
        )
        await ctx.send(embed=make_embed("INVITE TRACKER", desc, ACCENT_COLOR))

    @commands.hybrid_command(name="leaderboard", aliases=["lb", "topinv", "top"], description="View top inviters")
    async def leaderboard(self, ctx: commands.Context):
        rows = await get_leaderboard(10)
        lines = [
            f"`#{i:02d}` <@{r['user_id']}> - **{r['available']}** available "
            f"(`{r['regular_invites']}` reg / `{r['bonus_invites']}` bonus / `-{r['leave_invites']}` left)"
            for i, r in enumerate(rows, start=1)
        ]
        await ctx.send(embed=make_embed("INVITE LEADERBOARD", "\n".join(lines) or "No invite records yet.", ACCENT_COLOR))

    @commands.hybrid_command(name="whoinvited", description="Check who invited a member")
    async def whoinvited(self, ctx: commands.Context, member: discord.Member | None = None):
        target = member or ctx.author
        rec = await get_inviter_of(target.id)
        if not rec:
            return await ctx.send(embed=make_embed("INVITE LOOKUP", f"No invite record found for {target.mention}."))
        desc = (
            f"▸ Member: {target.mention}\n"
            f"▸ Inviter: <@{rec['inviter_id']}>\n"
            f"▸ Code Used: `{rec['invite_code']}`\n"
            f"▸ Joined: <t:{rec['joined_at']}:R>"
        )
        await ctx.send(embed=make_embed("INVITE LOOKUP", desc))


async def setup(bot):
    await bot.add_cog(InvitesCog(bot))

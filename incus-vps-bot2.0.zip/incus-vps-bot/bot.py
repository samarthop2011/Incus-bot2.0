import os

import discord
from discord.ext import commands
from dotenv import load_dotenv

from utils.db import init_db, load_config
from utils.embeds import error_embed
from utils.incus import preflight
from utils.invite_tracker import InviteTracker

load_dotenv()
TOKEN = os.getenv("DISCORD_TOKEN")
GUILD_ID = os.getenv("GUILD_ID")


def get_prefix(bot, message):
    cfg = load_config()
    return commands.when_mentioned_or(cfg["bot"].get("prefix", "!"))(bot, message)


class HostingBot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.members = True
        intents.message_content = True
        super().__init__(
            command_prefix=get_prefix,
            intents=intents,
            help_command=None,
            case_insensitive=True,
        )
        self.tracker = InviteTracker(self)
        self.deploying_users: set[int] = set()

    async def setup_hook(self):
        await init_db()

        issues = await preflight()
        if issues:
            for issue in issues:
                print(f"⚠ HOST CHECK: {issue}")
        else:
            print("◆ Local Incus host check passed")

        for cog in ["cogs.deploy", "cogs.vps_control", "cogs.invites", "cogs.admin", "cogs.general"]:
            await self.load_extension(cog)

        from cogs.deploy import DeployPanelView
        self.add_view(DeployPanelView(self))

        if GUILD_ID and GUILD_ID.isdigit():
            guild = discord.Object(id=int(GUILD_ID))
            self.tree.copy_global_to(guild=guild)
            await self.tree.sync(guild=guild)
        else:
            await self.tree.sync()

    async def on_ready(self):
        await self.tracker.cache_all_invites()
        cfg = load_config()
        await self.change_presence(
            activity=discord.Activity(
                type=discord.ActivityType.watching,
                name=f"{cfg['bot']['brand_name']} | {cfg['bot'].get('prefix', '!')}deploy",
            )
        )
        print(f"◆ Online as {self.user} ({self.user.id})")


bot = HostingBot()


@bot.event
async def on_member_join(member: discord.Member):
    await bot.tracker.on_member_join(member)


@bot.event
async def on_member_remove(member: discord.Member):
    await bot.tracker.on_member_remove(member)


@bot.event
async def on_invite_create(invite: discord.Invite):
    await bot.tracker.refresh_guild(invite.guild)


@bot.event
async def on_invite_delete(invite: discord.Invite):
    await bot.tracker.refresh_guild(invite.guild)


@bot.event
async def on_command_error(ctx: commands.Context, error: commands.CommandError):
    if isinstance(error, commands.CommandNotFound):
        return
    if isinstance(error, commands.CheckFailure):
        return await ctx.send(embed=error_embed("ACCESS DENIED", "You lack permissions for this command."))
    if isinstance(error, commands.BadArgument):
        return await ctx.send(embed=error_embed("INVALID ARGUMENT", str(error)[:500]))
    if isinstance(error, commands.MissingRequiredArgument):
        return await ctx.send(embed=error_embed("MISSING ARGUMENT", f"Missing parameter: `{error.param.name}`"))
    original = getattr(error, "original", error)
    await ctx.send(embed=error_embed("COMMAND ERROR", f"`{str(original)[:500]}`"))


@bot.tree.error
async def on_app_error(interaction: discord.Interaction, error: discord.app_commands.AppCommandError):
    original = getattr(error, "original", error)
    embed = error_embed("ERROR", f"`{str(original)[:500]}`")
    if interaction.response.is_done():
        await interaction.followup.send(embed=embed, ephemeral=True)
    else:
        await interaction.response.send_message(embed=embed, ephemeral=True)


if __name__ == "__main__":
    if not TOKEN:
        raise RuntimeError("DISCORD_TOKEN missing in .env")
    bot.run(TOKEN)

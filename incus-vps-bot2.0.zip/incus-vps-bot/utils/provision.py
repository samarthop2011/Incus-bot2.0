import asyncio
import time

from utils.db import create_vps_record, load_config
from utils.incus import (
    bootstrap_vps,
    check_capacity,
    create_ssh_link,
    gen_password,
    gen_vps_name,
    launch_vps,
    vps_action,
    wait_for_ipv4,
)

STEPS = [
    "Checking host capacity",
    "Creating container",
    "Waiting for private network",
    "Installing base system",
    "Opening SSH tunnel",
    "Saving instance",
]

_sem: asyncio.Semaphore | None = None


def deploy_semaphore() -> asyncio.Semaphore:
    global _sem
    if _sem is None:
        limit = load_config().get("host", {}).get("max_concurrent_deploys", 2)
        _sem = asyncio.Semaphore(max(1, int(limit)))
    return _sem


async def provision_vps(
    owner_id: int | str,
    plan_key: str,
    plan_name: str,
    ram_mb: int,
    cpu: int,
    disk_gb: int,
    os_name: str,
    image: str,
    ssh_type: str,
    progress=None,
) -> tuple[dict, str]:
    """Create a VPS on the local Incus host. Rolls back on failure.

    `progress` is an optional async callable: progress(step_index, note="").
    Returns (db_record, plaintext_password).
    """
    cfg = load_config()
    name = gen_vps_name(owner_id)
    password = gen_password()
    sem = deploy_semaphore()

    async def report(step: int, note: str = "") -> None:
        if progress:
            try:
                await progress(step, note)
            except Exception:
                pass

    if sem.locked():
        await report(0, "◈ Queued: waiting for another deployment to finish...")

    created = False
    async with sem:
        try:
            await report(0)
            await check_capacity(ram_mb, cpu)

            await report(1)
            await launch_vps(name, image, ram_mb, cpu, disk_gb)
            created = True

            await report(2)
            ip = await wait_for_ipv4(name)
            if not ip:
                raise RuntimeError(
                    "The container never received a private IPv4. Check the incusbr0 bridge / host firewall."
                )

            await report(3)
            await bootstrap_vps(name, password)

            await report(4)
            link = await create_ssh_link(name, ssh_type)

            await report(5)
            now = int(time.time())
            record = {
                "vps_id": name,
                "owner_id": str(owner_id),
                "plan_key": plan_key,
                "plan_name": plan_name,
                "ram_mb": ram_mb,
                "cpu": cpu,
                "disk_gb": disk_gb,
                "os_name": os_name,
                "image": image,
                "ip": ip,
                "ssh_type": ssh_type,
                "ssh_link": link,
                "status": "running",
                "created_at": now,
                "expires_at": now + cfg["settings"]["vps_expiry_days"] * 86400,
            }
            await create_vps_record(record)
        except BaseException:
            if created:
                try:
                    await vps_action(name, "delete")
                except Exception:
                    pass
            raise
    return record, password

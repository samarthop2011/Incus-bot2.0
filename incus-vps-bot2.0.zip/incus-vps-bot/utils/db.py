import json
import os

import aiosqlite

DB_PATH = "data/database.db"
CONFIG_PATH = "config.json"

ALLOWED_VPS_COLS = {
    "ip", "ssh_type", "ssh_link", "status", "warned_expiry",
    "expires_at", "os_name", "image",
}


def load_config() -> dict:
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def save_config(cfg: dict) -> None:
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2)


async def init_db() -> None:
    os.makedirs("data", exist_ok=True)
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("PRAGMA journal_mode=WAL")
        await db.executescript(
            """
            CREATE TABLE IF NOT EXISTS users (
                user_id TEXT PRIMARY KEY,
                regular_invites INTEGER DEFAULT 0,
                bonus_invites INTEGER DEFAULT 0,
                leave_invites INTEGER DEFAULT 0,
                fake_invites INTEGER DEFAULT 0,
                spent_invites INTEGER DEFAULT 0,
                blacklisted INTEGER DEFAULT 0,
                blacklist_reason TEXT DEFAULT '',
                last_deploy_at INTEGER DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS invite_records (
                member_id TEXT PRIMARY KEY,
                inviter_id TEXT,
                invite_code TEXT,
                is_fake INTEGER DEFAULT 0,
                left_server INTEGER DEFAULT 0,
                joined_at INTEGER
            );

            CREATE TABLE IF NOT EXISTS vps (
                vps_id TEXT PRIMARY KEY,
                owner_id TEXT,
                plan_key TEXT,
                plan_name TEXT,
                ram_mb INTEGER,
                cpu INTEGER,
                disk_gb INTEGER,
                os_name TEXT,
                image TEXT,
                ip TEXT,
                ssh_type TEXT,
                ssh_link TEXT,
                status TEXT DEFAULT 'running',
                warned_expiry INTEGER DEFAULT 0,
                created_at INTEGER,
                expires_at INTEGER
            );
            """
        )
        await db.commit()


async def ensure_user(db: aiosqlite.Connection, user_id: str) -> None:
    await db.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (str(user_id),))


async def get_user(user_id: int | str) -> dict:
    uid = str(user_id)
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        await ensure_user(db, uid)
        await db.commit()
        async with db.execute("SELECT * FROM users WHERE user_id=?", (uid,)) as cur:
            row = dict(await cur.fetchone())
    row["available"] = max(
        0,
        row["regular_invites"] + row["bonus_invites"]
        - row["leave_invites"] - row["fake_invites"] - row["spent_invites"],
    )
    return row


async def add_bonus_invites(user_id: int | str, delta: int) -> None:
    uid = str(user_id)
    async with aiosqlite.connect(DB_PATH) as db:
        await ensure_user(db, uid)
        await db.execute("UPDATE users SET bonus_invites = bonus_invites + ? WHERE user_id=?", (delta, uid))
        await db.commit()


async def add_spent_invites(user_id: int | str, amount: int) -> None:
    uid = str(user_id)
    async with aiosqlite.connect(DB_PATH) as db:
        await ensure_user(db, uid)
        await db.execute("UPDATE users SET spent_invites = spent_invites + ? WHERE user_id=?", (amount, uid))
        await db.commit()


async def set_last_deploy(user_id: int | str, ts: int) -> None:
    uid = str(user_id)
    async with aiosqlite.connect(DB_PATH) as db:
        await ensure_user(db, uid)
        await db.execute("UPDATE users SET last_deploy_at=? WHERE user_id=?", (ts, uid))
        await db.commit()


async def set_blacklist(user_id: int | str, flag: int, reason: str = "") -> None:
    uid = str(user_id)
    async with aiosqlite.connect(DB_PATH) as db:
        await ensure_user(db, uid)
        await db.execute("UPDATE users SET blacklisted=?, blacklist_reason=? WHERE user_id=?", (flag, reason, uid))
        await db.commit()


async def record_invite_join(member_id: int | str, inviter_id: int | str, code: str, is_fake: bool, ts: int) -> None:
    mid, iid = str(member_id), str(inviter_id)
    async with aiosqlite.connect(DB_PATH) as db:
        await ensure_user(db, iid)
        await db.execute(
            """INSERT OR REPLACE INTO invite_records
               (member_id, inviter_id, invite_code, is_fake, left_server, joined_at)
               VALUES (?, ?, ?, ?, 0, ?)""",
            (mid, iid, code, int(is_fake), ts),
        )
        col = "fake_invites" if is_fake else "regular_invites"
        await db.execute(f"UPDATE users SET {col} = {col} + 1 WHERE user_id=?", (iid,))
        await db.commit()


async def record_invite_leave(member_id: int | str) -> str | None:
    mid = str(member_id)
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM invite_records WHERE member_id=? AND left_server=0", (mid,)) as cur:
            row = await cur.fetchone()
        if not row:
            return None
        await db.execute("UPDATE invite_records SET left_server=1 WHERE member_id=?", (mid,))
        if not row["is_fake"]:
            await db.execute(
                "UPDATE users SET leave_invites = leave_invites + 1 WHERE user_id=?",
                (row["inviter_id"],),
            )
        await db.commit()
        return row["inviter_id"]


async def get_inviter_of(member_id: int | str) -> dict | None:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM invite_records WHERE member_id=?", (str(member_id),)) as cur:
            row = await cur.fetchone()
            return dict(row) if row else None


async def get_leaderboard(limit: int = 10) -> list[dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            """SELECT user_id,
               MAX(0, regular_invites + bonus_invites - leave_invites - fake_invites - spent_invites) AS available,
               regular_invites, bonus_invites, leave_invites
               FROM users
               ORDER BY available DESC LIMIT ?""",
            (limit,),
        ) as cur:
            return [dict(r) for r in await cur.fetchall()]


async def create_vps_record(data: dict) -> None:
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            """INSERT INTO vps (
                vps_id, owner_id, plan_key, plan_name, ram_mb, cpu, disk_gb,
                os_name, image, ip, ssh_type, ssh_link, status, warned_expiry,
                created_at, expires_at
            ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                data["vps_id"], data["owner_id"], data["plan_key"], data["plan_name"],
                data["ram_mb"], data["cpu"], data["disk_gb"], data["os_name"], data["image"],
                data["ip"], data["ssh_type"], data["ssh_link"], data["status"], 0,
                data["created_at"], data["expires_at"],
            ),
        )
        await db.commit()


async def get_vps(vps_id: str) -> dict | None:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM vps WHERE vps_id=?", (vps_id,)) as cur:
            row = await cur.fetchone()
            return dict(row) if row else None


async def get_user_vps(owner_id: int | str) -> list[dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM vps WHERE owner_id=? ORDER BY created_at DESC", (str(owner_id),)) as cur:
            return [dict(r) for r in await cur.fetchall()]


async def get_all_vps() -> list[dict]:
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM vps ORDER BY created_at DESC") as cur:
            return [dict(r) for r in await cur.fetchall()]


async def update_vps(vps_id: str, **fields) -> None:
    clean = {k: v for k, v in fields.items() if k in ALLOWED_VPS_COLS}
    if not clean:
        return
    sets = ", ".join(f"{k}=?" for k in clean)
    vals = list(clean.values()) + [vps_id]
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(f"UPDATE vps SET {sets} WHERE vps_id=?", vals)
        await db.commit()


async def delete_vps_record(vps_id: str) -> None:
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("DELETE FROM vps WHERE vps_id=?", (vps_id,))
        await db.commit()


async def get_allocated_totals() -> dict:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            "SELECT COUNT(*), COALESCE(SUM(ram_mb),0), COALESCE(SUM(cpu),0), COALESCE(SUM(disk_gb),0) FROM vps"
        ) as cur:
            c, r, p, d = await cur.fetchone()
    return {"count": c, "ram_mb": r, "cpu": p, "disk_gb": d}


async def get_global_stats() -> dict:
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute("SELECT status, COUNT(*) FROM vps GROUP BY status") as cur:
            by_status = {r[0]: r[1] for r in await cur.fetchall()}
        async with db.execute("SELECT COUNT(*) FROM users") as cur:
            users = (await cur.fetchone())[0]
    return {
        "total_vps": sum(by_status.values()),
        "running": by_status.get("running", 0),
        "stopped": by_status.get("stopped", 0),
        "suspended": by_status.get("suspended", 0),
        "other": sum(v for k, v in by_status.items() if k not in {"running", "stopped", "suspended"}),
        "users": users,
    }

import asyncio
import json
import os
import re
import secrets
import string

import psutil

from utils.db import get_allocated_totals, load_config

VALID_NAME_RE = re.compile(r"^[a-z0-9][a-z0-9-]{2,40}$")
SNAP_NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,40}$")
SSH_UNAVAILABLE = "Unavailable - press 'New SSH Link' in /myvps"


class CapacityError(RuntimeError):
    pass


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #
def assert_safe_name(name: str) -> str:
    if not VALID_NAME_RE.match(name or ""):
        raise ValueError(f"Unsafe instance name: {name!r}")
    return name


def assert_safe_snap(name: str) -> str:
    if not SNAP_NAME_RE.match(name or ""):
        raise ValueError(f"Unsafe snapshot name: {name!r}")
    return name


def gen_password(length: int = 16) -> str:
    alphabet = string.ascii_letters + string.digits
    return "".join(secrets.choice(alphabet) for _ in range(length))


def gen_vps_name(user_id: int | str) -> str:
    suffix = "".join(secrets.choice(string.ascii_lowercase + string.digits) for _ in range(4))
    return f"vps-{str(user_id)[-5:]}-{suffix}"


def _host_cfg() -> dict:
    return load_config().get("host", {})


# --------------------------------------------------------------------------- #
# Local Incus runner (no shell, no SSH: argument list only)
# --------------------------------------------------------------------------- #
async def run_incus(*args: str, timeout: int = 120, stdin: str | None = None) -> tuple[int, str, str]:
    binary = _host_cfg().get("incus_bin", "incus")
    try:
        proc = await asyncio.create_subprocess_exec(
            binary, *args,
            stdin=asyncio.subprocess.PIPE if stdin is not None else asyncio.subprocess.DEVNULL,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
    except FileNotFoundError:
        raise RuntimeError("Incus is not installed on this machine. Run scripts/setup_host.sh") from None
    try:
        out, err = await asyncio.wait_for(
            proc.communicate(stdin.encode() if stdin is not None else None),
            timeout=timeout,
        )
    except asyncio.TimeoutError:
        proc.kill()
        await proc.wait()
        raise RuntimeError(f"Incus command timed out after {timeout}s ({args[0]}).") from None
    return (
        proc.returncode or 0,
        out.decode(errors="replace").strip(),
        err.decode(errors="replace").strip(),
    )


async def exec_in(name: str, *cmd: str, stdin: str | None = None, timeout: int = 60):
    assert_safe_name(name)
    return await run_incus("exec", name, "--", *cmd, stdin=stdin, timeout=timeout)


async def exec_script(name: str, script: str, timeout: int = 180):
    return await exec_in(name, "sh", "-c", script, timeout=timeout)


# --------------------------------------------------------------------------- #
# In-container scripts
# --------------------------------------------------------------------------- #
BASE_SETUP_SCRIPT = r"""
has() { command -v "$1" >/dev/null 2>&1; }
export DEBIAN_FRONTEND=noninteractive
if has apt-get; then
  for i in 1 2 3; do apt-get update -y >/dev/null 2>&1 && break; sleep 3; done
  apt-get install -y curl ca-certificates >/dev/null 2>&1
  apt-get install -y openssh-client >/dev/null 2>&1
elif has apk; then
  apk add --no-cache curl ca-certificates >/dev/null 2>&1
  apk add --no-cache openssh-client >/dev/null 2>&1
elif has dnf; then
  has curl || dnf install -y curl ca-certificates >/dev/null 2>&1
  dnf install -y openssh-clients >/dev/null 2>&1
elif has pacman; then
  pacman -Sy --noconfirm curl ca-certificates openssh >/dev/null 2>&1
fi
has curl
"""

TMATE_SCRIPT = r"""
has() { command -v "$1" >/dev/null 2>&1; }
export DEBIAN_FRONTEND=noninteractive
if ! has tmate; then
  if has apt-get; then
    apt-get install -y tmate >/dev/null 2>&1 || { apt-get update -y >/dev/null 2>&1; apt-get install -y tmate >/dev/null 2>&1; }
  elif has apk; then apk add --no-cache tmate >/dev/null 2>&1
  elif has dnf; then dnf install -y tmate >/dev/null 2>&1
  elif has pacman; then pacman -Sy --noconfirm tmate >/dev/null 2>&1
  fi
fi
if ! has tmate; then
  case "$(uname -m)" in
    x86_64) A=amd64 ;;
    aarch64) A=arm64v8 ;;
    *) A= ;;
  esac
  if [ -n "$A" ] && has curl; then
    V=2.4.0
    curl -fsSL "https://github.com/tmate-io/tmate/releases/download/$V/tmate-$V-static-linux-$A.tar.xz" -o /tmp/tmate.tar.xz \
      && tar -xJf /tmp/tmate.tar.xz -C /tmp \
      && install -m 755 "/tmp/tmate-$V-static-linux-$A/tmate" /usr/local/bin/tmate
  fi
fi
has tmate || exit 1
S=/tmp/tmate.sock
tmate -S "$S" kill-server >/dev/null 2>&1
rm -f "$S"
tmate -S "$S" new-session -d || exit 1
timeout 60 tmate -S "$S" wait tmate-ready || exit 1
tmate -S "$S" display -p '#{tmate_ssh}'
tmate -S "$S" display -p '#{tmate_web}'
"""

SSHX_SCRIPT = r"""
has() { command -v "$1" >/dev/null 2>&1; }
has curl || exit 1
for p in /proc/[0-9]*; do
  if [ "$(cat "$p/comm" 2>/dev/null)" = "sshx" ]; then kill "${p#/proc/}" 2>/dev/null; fi
done
rm -f /tmp/sshx.log
setsid nohup sh -c 'curl -sSf https://sshx.io/get | sh -s run' >/tmp/sshx.log 2>&1 </dev/null &
i=0
while [ "$i" -lt 45 ]; do
  URL=$(grep -oE 'https://sshx\.io/s/[A-Za-z0-9_#-]+' /tmp/sshx.log 2>/dev/null | head -n 1)
  if [ -n "$URL" ]; then echo "$URL"; exit 0; fi
  i=$((i+1))
  sleep 1
done
exit 1
"""


# --------------------------------------------------------------------------- #
# Instance state
# --------------------------------------------------------------------------- #
def extract_ipv4(inst: dict | None) -> str | None:
    nets = ((inst or {}).get("state") or {}).get("network") or {}
    ordered = sorted(nets.items(), key=lambda kv: 0 if kv[0] == "eth0" else 1)
    for iface, data in ordered:
        if iface == "lo":
            continue
        for addr in data.get("addresses", []):
            if addr.get("family") == "inet" and addr.get("scope") == "global":
                return addr.get("address")
    return None


async def list_instances() -> dict[str, dict]:
    code, out, err = await run_incus("list", "--format", "json", timeout=45)
    if code != 0:
        raise RuntimeError(err or "incus list failed")
    return {i["name"]: i for i in json.loads(out or "[]")}


async def get_instance(name: str) -> dict | None:
    assert_safe_name(name)
    code, out, err = await run_incus("list", f"^{name}$", "--format", "json", timeout=20)
    if code != 0:
        raise RuntimeError(err or "incus list failed")
    data = json.loads(out or "[]")
    return data[0] if data else None


async def wait_for_ipv4(name: str, timeout: int = 90) -> str | None:
    loops = max(1, timeout // 2)
    for _ in range(loops):
        ip = extract_ipv4(await get_instance(name))
        if ip:
            return ip
        await asyncio.sleep(2)
    return None


async def get_live_stats(name: str) -> dict | None:
    inst = await get_instance(name)
    if not inst:
        return None
    st = inst.get("state") or {}
    mem = (st.get("memory") or {}).get("usage", 0) or 0
    disk = ((st.get("disk") or {}).get("root") or {}).get("usage", 0) or 0
    rx = tx = 0
    for iface, data in (st.get("network") or {}).items():
        if iface == "lo":
            continue
        counters = data.get("counters") or {}
        rx += counters.get("bytes_received", 0) or 0
        tx += counters.get("bytes_sent", 0) or 0
    return {
        "state": (inst.get("status") or "unknown").lower(),
        "mem_mb": mem / 1048576,
        "disk_gb": disk / 1073741824,
        "procs": st.get("processes", 0) or 0,
        "rx_mb": rx / 1048576,
        "tx_mb": tx / 1048576,
        "ip": extract_ipv4(inst),
    }


# --------------------------------------------------------------------------- #
# Lifecycle
# --------------------------------------------------------------------------- #
async def _cleanup(name: str) -> None:
    try:
        await run_incus("delete", name, "--force", timeout=60)
    except Exception:
        pass


async def launch_vps(name: str, image: str, ram_mb: int, cpu: int, disk_gb: int) -> None:
    assert_safe_name(name)
    host = _host_cfg()
    base = [
        "launch", image, name,
        "-c", f"limits.cpu={int(cpu)}",
        "-c", f"limits.memory={int(ram_mb)}MiB",
    ]
    if host.get("nesting", True):
        base += ["-c", "security.nesting=true"]

    code, _, err = await run_incus(*base, "-d", f"root,size={int(disk_gb)}GiB", timeout=420)
    if code != 0:
        await _cleanup(name)
        quota_problem = "quota" in err.lower() or "size" in err.lower()
        if host.get("allow_unquoted_disk", False) and quota_problem:
            code, _, err = await run_incus(*base, timeout=420)
        if code != 0:
            await _cleanup(name)
            hint = " (storage pool has no quota support: use btrfs/zfs)" if quota_problem else ""
            raise RuntimeError(f"Incus launch failed{hint}: {err[-350:]}")


async def set_root_password(name: str, password: str) -> None:
    err = ""
    for _ in range(5):
        code, _, err = await exec_in(name, "chpasswd", stdin=f"root:{password}\n", timeout=30)
        if code == 0:
            return
        await asyncio.sleep(2)
    raise RuntimeError(f"Could not set root password: {err[-200:]}")


async def bootstrap_vps(name: str, password: str) -> None:
    await set_root_password(name, password)
    code, _, _ = await exec_script(name, BASE_SETUP_SCRIPT, timeout=300)
    if code != 0:
        raise RuntimeError(
            "Base setup failed: the container likely has no outbound internet. "
            "Check the host firewall / NAT (see README troubleshooting)."
        )


async def create_ssh_link(name: str, ssh_type: str) -> str:
    assert_safe_name(name)
    script = TMATE_SCRIPT if ssh_type == "tmate" else SSHX_SCRIPT
    try:
        code, out, _ = await exec_script(name, script, timeout=180)
    except RuntimeError:
        return SSH_UNAVAILABLE
    lines = [ln.strip() for ln in out.splitlines() if ln.strip()]
    if ssh_type == "tmate":
        lines = [ln for ln in lines if ln.startswith(("ssh ", "http"))]
        if code != 0 or not lines:
            return SSH_UNAVAILABLE
        return "\n".join(lines[-2:])
    lines = [ln for ln in lines if ln.startswith("https://sshx.io/")]
    if code != 0 or not lines:
        return SSH_UNAVAILABLE
    return lines[-1]


async def vps_action(name: str, action: str) -> None:
    assert_safe_name(name)
    cmds = {
        "start": ["start", name],
        "stop": ["stop", name, "--force"],
        "restart": ["restart", name, "--force"],
        "delete": ["delete", name, "--force"],
    }
    if action not in cmds:
        raise ValueError("Invalid action")
    code, _, err = await run_incus(*cmds[action], timeout=120)
    if code == 0:
        return
    low = err.lower()
    if action == "delete" and "not found" in low:
        return
    if action == "start" and "already running" in low:
        return
    if action == "stop" and ("not running" in low or "already stopped" in low):
        return
    raise RuntimeError(err[-300:] or f"Failed to {action}")


async def snapshot_action(name: str, action: str, snap: str | None = None) -> list[str]:
    assert_safe_name(name)
    if action == "list":
        code, out, err = await run_incus("query", f"/1.0/instances/{name}/snapshots", timeout=30)
        if code != 0:
            raise RuntimeError(err[-300:] or "Could not list snapshots")
        return sorted(p.rsplit("/", 1)[-1] for p in json.loads(out or "[]"))
    assert_safe_snap(snap or "")
    cmds = {
        "create": ["snapshot", "create", name, snap],
        "restore": ["snapshot", "restore", name, snap],
        "delete": ["snapshot", "delete", name, snap],
    }
    if action not in cmds:
        raise ValueError("Invalid snapshot action")
    code, _, err = await run_incus(*cmds[action], timeout=180)
    if code != 0:
        raise RuntimeError(err[-300:] or "Snapshot operation failed")
    return []


# --------------------------------------------------------------------------- #
# Host capacity / health (single local node)
# --------------------------------------------------------------------------- #
def capacity_limits() -> dict:
    h = _host_cfg()
    total_mb = psutil.virtual_memory().total / 1048576
    usable_ram = max(0.0, total_mb - h.get("reserve_ram_mb", 2048)) * h.get("ram_overcommit", 1.0)
    cores = psutil.cpu_count(logical=True) or 1
    return {
        "max_vps": h.get("max_total_vps", 40),
        "ram_mb": int(usable_ram),
        "cpu": cores * h.get("cpu_overcommit", 4.0),
    }


def _storage_path() -> str:
    for p in ("/var/lib/incus", "/var/snap/incus/common/incus", "/"):
        if os.path.exists(p):
            return p
    return "/"


async def check_capacity(ram_mb: int, cpu: int) -> None:
    h = _host_cfg()
    cap = capacity_limits()
    totals = await get_allocated_totals()
    if totals["count"] >= cap["max_vps"]:
        raise CapacityError("The host has reached its maximum VPS count. Try again later.")
    if totals["ram_mb"] + ram_mb > cap["ram_mb"]:
        raise CapacityError("Not enough free RAM capacity on the host for this plan.")
    if totals["cpu"] + cpu > cap["cpu"]:
        raise CapacityError("Not enough free CPU capacity on the host for this plan.")
    free_gb = psutil.disk_usage(_storage_path()).free / 1073741824
    if free_gb < h.get("min_free_disk_gb", 10):
        raise CapacityError("The host is low on disk space. Try again later.")


async def get_host_stats() -> dict:
    def _collect() -> dict:
        vm = psutil.virtual_memory()
        du = psutil.disk_usage(_storage_path())
        try:
            load = os.getloadavg()
        except OSError:
            load = (0.0, 0.0, 0.0)
        return {
            "cpu_percent": psutil.cpu_percent(interval=0.4),
            "cores": psutil.cpu_count(logical=True) or 1,
            "ram_used_gb": vm.used / 1073741824,
            "ram_total_gb": vm.total / 1073741824,
            "disk_used_gb": du.used / 1073741824,
            "disk_total_gb": du.total / 1073741824,
            "disk_free_gb": du.free / 1073741824,
            "load": load,
        }
    return await asyncio.to_thread(_collect)


async def get_incus_version() -> str:
    code, out, err = await run_incus("version", timeout=15)
    if code != 0:
        raise RuntimeError(err or out or "incus version failed")
    for line in out.splitlines():
        if line.lower().startswith("server version"):
            return line.split(":", 1)[1].strip()
    return out.splitlines()[0] if out else "unknown"


async def preflight() -> list[str]:
    issues: list[str] = []
    try:
        code, out, err = await run_incus("version", timeout=15)
    except RuntimeError as exc:
        return [str(exc)]
    if code != 0:
        return [f"`incus version` failed: {err or out}. Run the bot as root or add its user to the incus-admin group."]
    code, out, err = await run_incus("profile", "show", "default", timeout=15)
    if code != 0:
        issues.append(f"Cannot read the default profile: {err}")
    else:
        if "path: /" not in out:
            issues.append("Default profile has no root disk. Run scripts/setup_host.sh")
        if "type: nic" not in out:
            issues.append("Default profile has no network device. Run scripts/setup_host.sh")
    return issues

import datetime

import discord

from utils.db import load_config

MAIN_COLOR = 0x2B2D31
ACCENT_COLOR = 0x00B4D8
SUCCESS_COLOR = 0x00D492
WARN_COLOR = 0xF5A623
ERROR_COLOR = 0xFF4D4D


def fmt_gb(mb: float) -> str:
    return f"{mb / 1024:g}"


def make_embed(title: str, description: str, color: int = MAIN_COLOR) -> discord.Embed:
    brand = load_config()["bot"].get("brand_name", "NEXUS HOSTING")
    embed = discord.Embed(
        title=f"╭─ {title} ─╮",
        description=f"{description}\n\n╰{'─' * 34}╯",
        color=color,
        timestamp=datetime.datetime.now(datetime.timezone.utc),
    )
    embed.set_footer(text=f"◆ {brand} • Incus Cloud Infrastructure")
    return embed


def success_embed(title: str, description: str) -> discord.Embed:
    return make_embed(f"◆ {title}", description, SUCCESS_COLOR)


def error_embed(title: str, description: str) -> discord.Embed:
    return make_embed(f"◇ {title}", description, ERROR_COLOR)


def warn_embed(title: str, description: str) -> discord.Embed:
    return make_embed(f"◈ {title}", description, WARN_COLOR)


def progress_embed(title: str, steps: list[str], current: int, details: str = "") -> discord.Embed:
    total = len(steps)
    bar = "▰" * current + "▱" * (total - current)
    pct = int(current / total * 100)
    lines = []
    for i, step in enumerate(steps):
        if i < current:
            lines.append(f"◆ {step}")
        elif i == current:
            lines.append(f"▸ **{step}...**")
        else:
            lines.append(f"◇ {step}")
    desc = f"{details}\n\n" if details else ""
    desc += "\n".join(lines) + f"\n\n`{bar}` **{pct}%**"
    return make_embed(title, desc, ACCENT_COLOR)


def plans_embed(cfg: dict) -> discord.Embed:
    lines = [
        "**◆ Invite-Based VPS Deployment ◆**",
        "▸ Engine: `Incus Containers`  |  Host: `Local Node`",
        f"▸ Expiry: `{cfg['settings']['vps_expiry_days']} Days`  |  Access: `sshx / tmate`",
        "▸ Network: `Private NAT • no public IP needed`",
        "",
        "━━━━━━━━━━━━ **PLAN TIERS** ━━━━━━━━━━━━",
    ]
    for p in cfg["plans"].values():
        if p.get("custom"):
            specs = "RAM: `Custom`  |  CPU: `Custom`  |  SSD: `Custom`"
            badge = "◈ Custom Tier"
        else:
            specs = f"RAM: `{fmt_gb(p['ram_mb'])} GB`  |  CPU: `{p['cpu']} vCore`  |  SSD: `{p['disk_gb']} GB`"
            badge = "◆ Available"
        lines.append(
            f"┌─ **{p['name']}** ──────── `{p['invites']} Invites`\n"
            f"│  ├ {specs}\n"
            f"│  └ Status: `{badge}`"
        )
    return make_embed("VPS DEPLOYMENT PANEL", "\n".join(lines), ACCENT_COLOR)


def vps_credentials_embed(vps: dict, password: str | None = None) -> discord.Embed:
    if password:
        pw_line = f"│  ├ Password: ||`{password}`|| *(shown once, save it)*\n"
    else:
        pw_line = "│  ├ Password: `hidden` (use **Reset Password**)\n"
    desc = (
        f"┌─ **Instance Info**\n"
        f"│  ├ ID: `{vps['vps_id']}`\n"
        f"│  ├ Plan: `{vps['plan_name']}`\n"
        f"│  ├ Specs: `{fmt_gb(vps['ram_mb'])} GB RAM` | `{vps['cpu']} vCore` | `{vps['disk_gb']} GB SSD`\n"
        f"│  └ OS: `{vps['os_name']}`\n\n"
        f"┌─ **Access**\n"
        f"│  ├ Private IPv4: `{vps['ip']}` *(internal NAT, no public IP needed)*\n"
        f"│  ├ User: `root`\n"
        f"{pw_line}"
        f"│  └ Tunnel ({vps['ssh_type']}):\n"
        f"```\n{vps['ssh_link']}\n```\n"
        f"┌─ **Lifecycle**\n"
        f"│  └ Expires: <t:{vps['expires_at']}:R>\n\n"
        f"▸ Tunnels restart with the VPS. Use **New SSH Link** after a restart.\n"
        f"▸ Manage anytime with `/myvps` or `!myvps`"
    )
    return success_embed("VPS READY", desc)


def vps_dashboard_embed(vps: dict, live: dict | None = None) -> discord.Embed:
    live_block = ""
    if live:
        live_block = (
            f"\n┌─ **Live Telemetry**\n"
            f"│  ├ State: `{live['state']}`\n"
            f"│  ├ RAM: `{live['mem_mb']:.0f} / {vps['ram_mb']} MB`\n"
            f"│  ├ Disk: `{live['disk_gb']:.1f} / {vps['disk_gb']} GB`\n"
            f"│  ├ Processes: `{live['procs']}`\n"
            f"│  └ Traffic: `↓ {live['rx_mb']:.1f} MB` | `↑ {live['tx_mb']:.1f} MB`\n"
        )
    desc = (
        f"┌─ **Instance Overview**\n"
        f"│  ├ ID: `{vps['vps_id']}`\n"
        f"│  ├ Status: `{vps['status'].upper()}`\n"
        f"│  ├ Plan: `{vps['plan_name']}`\n"
        f"│  ├ Resources: `{fmt_gb(vps['ram_mb'])} GB` | `{vps['cpu']} vCore` | `{vps['disk_gb']} GB SSD`\n"
        f"│  ├ OS: `{vps['os_name']}`\n"
        f"│  ├ Private IPv4: `{vps['ip']}`\n"
        f"│  └ Expires: <t:{vps['expires_at']}:R>\n"
        f"{live_block}"
    )
    color = SUCCESS_COLOR if vps["status"] == "running" else WARN_COLOR
    return make_embed(f"CONTROL PANEL • {vps['vps_id']}", desc, color)


async def build_host_embed(admin: bool = False) -> discord.Embed:
    from utils.db import get_allocated_totals, get_global_stats
    from utils.incus import capacity_limits, get_host_stats, get_incus_version

    hs = await get_host_stats()
    gs = await get_global_stats()
    tot = await get_allocated_totals()
    cap = capacity_limits()

    desc = (
        f"┌─ **Capacity**\n"
        f"│  ├ VPS Slots: `{tot['count']} / {cap['max_vps']}`\n"
        f"│  ├ RAM Allocated: `{tot['ram_mb'] / 1024:.1f} / {cap['ram_mb'] / 1024:.1f} GB`\n"
        f"│  ├ vCPU Allocated: `{tot['cpu']} / {cap['cpu']:.0f}`\n"
        f"│  └ Running `{gs['running']}` • Stopped `{gs['stopped']}` • Suspended `{gs['suspended']}`\n\n"
        f"┌─ **Host Health**\n"
        f"│  ├ CPU Usage: `{hs['cpu_percent']:.1f}%` ({hs['cores']} threads)\n"
        f"│  ├ RAM: `{hs['ram_used_gb']:.1f} / {hs['ram_total_gb']:.1f} GB`\n"
        f"│  ├ Disk: `{hs['disk_used_gb']:.0f} / {hs['disk_total_gb']:.0f} GB` (`{hs['disk_free_gb']:.0f} GB free`)\n"
        f"│  └ Load Avg: `{hs['load'][0]:.2f} {hs['load'][1]:.2f} {hs['load'][2]:.2f}`\n\n"
        f"┌─ **Network**\n"
        f"│  └ Mode: `Private NAT bridge • no public IP required`"
    )
    if admin:
        try:
            ver = await get_incus_version()
        except Exception as exc:
            ver = f"error: {exc}"
        desc += f"\n\n┌─ **Admin**\n│  ├ Incus: `{ver}`\n│  └ Tracked Users: `{gs['users']}` • Other states: `{gs['other']}`"
    return make_embed("HOST STATUS", desc, ACCENT_COLOR)

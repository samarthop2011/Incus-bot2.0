import datetime

import discord

from utils.db import get_user, load_config, record_invite_join, record_invite_leave
from utils.embeds import SUCCESS_COLOR, WARN_COLOR, make_embed


class InviteTracker:
    def __init__(self, bot: discord.Client):
        self.bot = bot
        self.cache: dict[int, dict[str, int]] = {}

    async def cache_all_invites(self) -> None:
        for guild in self.bot.guilds:
            await self.refresh_guild(guild)

    async def refresh_guild(self, guild: discord.Guild) -> None:
        try:
            invites = await guild.invites()
            self.cache[guild.id] = {inv.code: (inv.uses or 0) for inv in invites}
        except discord.Forbidden:
            pass

    async def on_member_join(self, member: discord.Member) -> None:
        if member.bot:
            return
        guild = member.guild
        cfg = load_config()
        try:
            new_invites = await guild.invites()
        except discord.Forbidden:
            return

        old = self.cache.get(guild.id, {})
        used_invite = None
        for inv in new_invites:
            if (inv.uses or 0) > old.get(inv.code, 0):
                used_invite = inv
                break

        self.cache[guild.id] = {inv.code: (inv.uses or 0) for inv in new_invites}
        if not used_invite or not used_invite.inviter or used_invite.inviter.bot:
            return

        inviter = used_invite.inviter
        if inviter.id == member.id:
            return
        min_days = cfg["settings"].get("min_account_age_days", 7)
        age_days = (datetime.datetime.now(datetime.timezone.utc) - member.created_at).days
        is_fake = age_days < min_days

        await record_invite_join(
            member.id,
            inviter.id,
            used_invite.code,
            is_fake,
            int(datetime.datetime.now(datetime.timezone.utc).timestamp()),
        )

        stats = await get_user(inviter.id)
        inviter_member = guild.get_member(inviter.id)
        if inviter_member and not is_fake:
            for req_str, role_id in cfg["settings"].get("invite_roles", {}).items():
                if role_id and stats["available"] >= int(req_str):
                    role = guild.get_role(int(role_id))
                    if role and role not in inviter_member.roles:
                        try:
                            await inviter_member.add_roles(role, reason="Invite milestone reached")
                        except discord.Forbidden:
                            pass

        ch_id = cfg["settings"].get("invite_log_channel_id", 0)
        if ch_id:
            ch = guild.get_channel(int(ch_id))
            if ch:
                tag = "◇ Flagged Fake (New Account)" if is_fake else "◆ Valid Invite"
                embed = make_embed(
                    "MEMBER JOINED",
                    f"▸ Member: {member.mention} (`{member.id}`)\n"
                    f"▸ Invited By: {inviter.mention} (`{stats['available']}` available)\n"
                    f"▸ Status: `{tag}`",
                    SUCCESS_COLOR if not is_fake else WARN_COLOR,
                )
                await ch.send(embed=embed)

    async def on_member_remove(self, member: discord.Member) -> None:
        if member.bot:
            return
        inviter_id = await record_invite_leave(member.id)
        if not inviter_id:
            return
        cfg = load_config()
        ch_id = cfg["settings"].get("invite_log_channel_id", 0)
        if ch_id:
            ch = member.guild.get_channel(int(ch_id))
            if ch:
                stats = await get_user(inviter_id)
                embed = make_embed(
                    "MEMBER LEFT",
                    f"▸ Member: `{member}` (`{member.id}`)\n"
                    f"▸ Inviter: <@{inviter_id}> (Now `{stats['available']}` available)",
                    WARN_COLOR,
                )
                await ch.send(embed=embed)

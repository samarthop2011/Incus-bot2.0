#!/usr/bin/env bash
set -euo pipefail
if [ "$(id -u)" -ne 0 ]; then echo "Run as root"; exit 1; fi
DIR="$(cd "$(dirname "$0")/.." && pwd)"
cat >/etc/systemd/system/incus-bot.service <<EOF
[Unit]
Description=Incus VPS Discord Bot
After=network-online.target incus.service
Wants=network-online.target

[Service]
User=root
WorkingDirectory=${DIR}
ExecStart=${DIR}/venv/bin/python3 bot.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable --now incus-bot
echo "Service installed. Logs: journalctl -u incus-bot -f"

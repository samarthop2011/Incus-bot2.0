#!/usr/bin/env bash
# Installs and initialises Incus on THIS machine. No remote access is configured.
set -euo pipefail

if [ "$(id -u)" -ne 0 ]; then
  echo "Run as root: sudo bash scripts/setup_host.sh"
  exit 1
fi

POOL_SIZE_GB="${POOL_SIZE_GB:-200}"
STORAGE_BACKEND="${STORAGE_BACKEND:-btrfs}"   # btrfs | zfs | dir (dir has NO disk quotas)

echo "=== Installing packages ==="
apt-get update -y
apt-get install -y curl gpg ca-certificates python3 python3-venv python3-pip
case "$STORAGE_BACKEND" in
  btrfs) apt-get install -y btrfs-progs ;;
  zfs)   apt-get install -y zfsutils-linux ;;
esac

if ! command -v incus >/dev/null 2>&1; then
  echo "=== Installing Incus (Zabbly stable repo) ==="
  mkdir -p /etc/apt/keyrings/
  curl -fsSL https://pkgs.zabbly.com/key.asc -o /etc/apt/keyrings/zabbly.asc
  . /etc/os-release
  cat <<EOF >/etc/apt/sources.list.d/zabbly-incus-stable.sources
Enabled: yes
Types: deb
URIs: https://pkgs.zabbly.com/incus/stable
Suites: ${VERSION_CODENAME}
Components: main
Architectures: $(dpkg --print-architecture)
Signed-By: /etc/apt/keyrings/zabbly.asc
EOF
  apt-get update -y
  apt-get install -y incus
fi

systemctl enable --now incus >/dev/null 2>&1 || true

if ! incus profile show default 2>/dev/null | grep -q "root:"; then
  echo "=== Initialising Incus (${STORAGE_BACKEND}, local only, API NOT exposed) ==="
  if [ "$STORAGE_BACKEND" = "dir" ]; then
    incus admin init --auto --storage-backend dir
  else
    incus admin init --auto --storage-backend "$STORAGE_BACKEND" --storage-create-loop "$POOL_SIZE_GB"
  fi
else
  echo "=== Incus already initialised, skipping init ==="
fi

echo "=== Configuring private NAT bridge (no IPv6, no public IP needed) ==="
if incus network show incusbr0 >/dev/null 2>&1; then
  incus network set incusbr0 ipv6.address none || true
  incus network set incusbr0 ipv4.nat true || true
else
  incus network create incusbr0 ipv4.address=auto ipv4.nat=true ipv6.address=none
fi
if ! incus profile show default | grep -q "type: nic"; then
  incus profile device add default eth0 nic network=incusbr0 name=eth0
fi

if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q "Status: active"; then
  echo "=== UFW detected: allowing the Incus bridge ==="
  ufw allow in on incusbr0 || true
  ufw route allow in on incusbr0 || true
  ufw route allow out on incusbr0 || true
fi

echo "=== Self-test: throwaway container ==="
if incus launch images:alpine/3.20 incus-selftest >/dev/null 2>&1; then
  ok=0
  for i in $(seq 1 30); do
    if incus exec incus-selftest -- ping -c1 -W2 1.1.1.1 >/dev/null 2>&1; then ok=1; break; fi
    sleep 2
  done
  if [ "$ok" = 1 ]; then
    echo "Self-test PASSED: containers have outbound internet (NAT works)."
  else
    echo "WARNING: container has no outbound internet. See README troubleshooting."
  fi
  incus delete -f incus-selftest >/dev/null 2>&1 || true
else
  echo "WARNING: could not launch the test container. Check: incus launch images:alpine/3.20 test"
fi

echo "=== Host ready. Next: create venv, edit .env + config.json, run python3 bot.py ==="
